// Drakula theme colors
/*-- https://drakulatheme.com/contribue --*/

export const BACKGROUND = "#282A36" ;
export const CURRENTLINE = "#44475A"
export const FOREGROUND = "#F8F8F2"
export const COMENT = "#6272A4"
export const CYAN = "#8BE9FD"
export const GREEN = "#50FA7B"
export const ORANGE ="#FFB86C"
export const PINK ="#FF79C6"
export const PURPLE ="#BD93F9"
export const RED ="#FF5555"
export const YELLOW = "#F1FA8C" 