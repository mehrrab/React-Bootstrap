const team = [
    {
        id : 1 ,
        name : "Mehrab Shakeripour"  ,
        job :"CHIEF EXECUTIVE OFFICER" ,
        imgUrl : "/src/assets/img/me.jpg",
        phone : "09150952636" , 
        email : "Altar.computer81@gmail.com" ,
    } ,

    {
        id : 2 ,
        name : "Shahyar Rad "  ,
        job :"PRODUCT MANAGER" ,
        imgUrl : "/src/assets/img/he.jpg",
        phone : "09059749483" , 
        email : "shahyar.computer81@gmail.com",
    } ,
    {
        id : 3 ,
        name : "Nasim kahani "  ,
        job :"CTO" ,
        imgUrl : "/src/assets/img/he2.jpg",
        phone : "09059749483" , 
        email : "nasim.computer81@gmail.com",
    } ,

   
]
export  default team